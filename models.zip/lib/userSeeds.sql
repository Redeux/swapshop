USE swapshop_db;

INSERT INTO users (username, password, emailAddress, firstName, lastName, streetAddress, city, state, zipcode) VALUES ("Gillian_Welch", "Hardtimes1!", "gillian@gmail.com", "Gillian", "Welch", "205 Willow Way", "Los Angeles", "California", "90210");

INSERT INTO users (username, password, emailAddress, firstName, lastName, streetAddress, city, state, zipcode) VALUES ("robsthebest", "abcefghi1", "robyoung@hotmail.com", "Rob", "Young", "9A Canterbury Lane", "Balitmore", "Maryland", "30028");

INSERT INTO users (username, password, emailAddress, firstName, lastName, streetAddress, city, state, zipcode) VALUES ("amphigorey", "wugglyUmp", "edwardgorey@msn.com", "Edward", "Gorey", "21 Koelnstrasse", "Koeln", "Germany", "43902");