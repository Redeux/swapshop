INSERT INTO SwapItems (swapItem1, swapItem2, state) VALUES (1, 2, 'Complete');
INSERT INTO SwapItems (swapItem1, swapItem2, state) VALUES (3, 1, 'Pending');
